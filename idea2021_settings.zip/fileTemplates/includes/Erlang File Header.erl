#parse("Erlang Custom Template Variables.erl")
%%%-------------------------------------------------------------------
%%% @author ${FULLNAME}
%%% @copyright (C) ${YEAR}, ${COMPANY}
%%% @doc
%%%     TODO 模块描述
%%% @end
%%% Created : ${DAY}. ${MONTH_NAME_SHORT} ${YEAR} ${TIME}
%%%-------------------------------------------------------------------
