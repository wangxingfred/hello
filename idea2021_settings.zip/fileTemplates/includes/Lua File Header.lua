#parse("Erlang Custom Template Variables.erl")
-----------------------------------------------------------------------
-- Created by ${FULLNAME} on ${DAY}. ${MONTH_NAME_SHORT} ${YEAR} ${TIME}
--
-- @Description TODO 模块描述
-----------------------------------------------------------------------
