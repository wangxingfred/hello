#set( $FULLNAME = "fred" )
#set( $COMPANY = "<Woobest>" )
#set( $EMAIL = "'wangxingfred@gmail.com'" )
