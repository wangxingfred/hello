#parse("Erlang Custom Template Variables.erl")
    @moduledoc ~S"""
    Copyright ${COMPANY} ${YEAR}. All Rights Reserved.
      
    History:
        ${YEAR}-${MONTH}-${DAY} ${TIME}, ${FULLNAME} ${EMAIL}, create module
    
    TODO 编写模块描述
    """
    #[[]]#
